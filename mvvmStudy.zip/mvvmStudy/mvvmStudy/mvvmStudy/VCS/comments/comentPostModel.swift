//
//  comentPostModel.swift
//  mvvmStudy
//
//  Created by Abin on 05/05/20.
//  Copyright © 2020 Abin. All rights reserved.
//

import Foundation


// MARK: - PostElement
struct ComentElement: Codable {
    var postID, id: Int?
    var name, email, body: String?

    enum CodingKeys: String, CodingKey {
        case postID = "postId"
        case id, name, email, body
    }
}

typealias Comments = [ComentElement]
