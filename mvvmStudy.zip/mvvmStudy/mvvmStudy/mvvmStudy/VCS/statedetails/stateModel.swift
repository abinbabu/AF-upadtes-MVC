//
//  stateModel.swift
//  mvvmStudy
//
//  Created by Abin on 27/04/20.
//  Copyright © 2020 Abin. All rights reserved.
//

import Foundation


// MARK: - PostElement
struct PostElement: Codable {
    var userID, id: Int?
    var title, body: String?

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}

typealias Post = [PostElement]
