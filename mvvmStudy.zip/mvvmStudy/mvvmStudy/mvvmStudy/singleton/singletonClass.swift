//
//  singletonClass.swift
//  mvvmStudy
//
//  Created by Abin on 08/05/20.
//  Copyright © 2020 Abin. All rights reserved.
//

import Foundation
/******************ProfileDetails*******************/

class CustomerPrf {
    private init() { }
    static let info = CustomerPrf()
    
    var accessT = ""


}
